"""
Rover Autonomy System — Vision + Detection
Stack: YOLO11n + OpenCV + Ultralytics
USB 1080p webcam input

Run modes:
  python rover_autonomy.py --mode test       # camera + detection diagnostics
  python rover_autonomy.py --mode live       # full live feed with decisions
  python rover_autonomy.py --mode benchmark  # FPS + latency report
"""

import cv2
import time
import argparse
import sys
from collections import deque
from dataclasses import dataclass, field
from typing import Optional

try:
    from ultralytics import YOLO
except ImportError:
    print("[ERROR] ultralytics not installed. Run: pip install ultralytics")
    sys.exit(1)

# ─── Config ────────────────────────────────────────────────────────────────────

CAMERA_INDEX      = 0          # USB webcam — change if multiple cameras
CAPTURE_WIDTH     = 1280       # Downsample from 1080p for faster inference
CAPTURE_HEIGHT    = 720
MODEL_PATH        = "yolo11n.pt"  # Auto-downloaded on first run (~6MB)
CONF_THRESHOLD    = 0.45
IOU_THRESHOLD     = 0.45

# Danger zone: centre column of frame as fraction of width
# If an obstacle occupies this zone -> STOP or STEER
DANGER_ZONE_LEFT  = 0.30
DANGER_ZONE_RIGHT = 0.70
DANGER_ZONE_MIN_AREA = 0.04    # min fraction of frame area to count as obstacle

# Classes that count as navigation obstacles (COCO class names)
OBSTACLE_CLASSES = {
    "person", "bicycle", "car", "motorcycle", "bus", "truck",
    "cat", "dog", "chair", "dining table", "bench", "potted plant",
    "backpack", "suitcase", "bottle", "cup", "laptop", "tv",
    "couch", "bed", "toilet", "door"
}

# ─── Data structures ───────────────────────────────────────────────────────────

@dataclass
class Detection:
    label: str
    confidence: float
    x1: int
    y1: int
    x2: int
    y2: int

    @property
    def cx(self): return (self.x1 + self.x2) // 2
    @property
    def cy(self): return (self.y1 + self.y2) // 2
    @property
    def area(self): return (self.x2 - self.x1) * (self.y2 - self.y1)

@dataclass
class RoverDecision:
    action: str           # FORWARD / STOP / STEER_LEFT / STEER_RIGHT
    reason: str
    obstacles: list = field(default_factory=list)
    confidence: float = 1.0

# ─── Motor stub (replace with your actual motor driver calls) ──────────────────

class MotorController:
    """
    Stub controller — replace body of each method with your
    actual RPi GPIO / serial / I2C motor driver calls.
    """
    def __init__(self, dry_run=True):
        self.dry_run = dry_run
        self._last_action = None

    def forward(self, speed=0.5):
        if self._last_action != "FORWARD":
            self._log(f"FORWARD  speed={speed:.2f}")
            self._last_action = "FORWARD"

    def stop(self):
        if self._last_action != "STOP":
            self._log("STOP")
            self._last_action = "STOP"

    def steer_left(self, speed=0.4):
        if self._last_action != "STEER_LEFT":
            self._log(f"STEER_LEFT  speed={speed:.2f}")
            self._last_action = "STEER_LEFT"

    def steer_right(self, speed=0.4):
        if self._last_action != "STEER_RIGHT":
            self._log(f"STEER_RIGHT  speed={speed:.2f}")
            self._last_action = "STEER_RIGHT"

    def _log(self, msg):
        prefix = "[DRY-RUN]" if self.dry_run else "[MOTOR]"
        print(f"{prefix} {msg}")

# ─── Decision engine ───────────────────────────────────────────────────────────

class DecisionEngine:
    def __init__(self, frame_w: int, frame_h: int):
        self.frame_w = frame_w
        self.frame_h = frame_h
        self.frame_area = frame_w * frame_h
        self._history = deque(maxlen=5)  # smooth decisions over last N frames

    def decide(self, detections: list[Detection]) -> RoverDecision:
        obstacles = [
            d for d in detections
            if d.label in OBSTACLE_CLASSES
            and d.area / self.frame_area >= DANGER_ZONE_MIN_AREA
        ]

        centre_obstacles = [
            d for d in obstacles
            if self._in_danger_zone(d)
        ]

        if not centre_obstacles:
            decision = RoverDecision("FORWARD", "path clear")
        else:
            # Pick largest obstacle in danger zone
            blocker = max(centre_obstacles, key=lambda d: d.area)
            cx_norm = blocker.cx / self.frame_w

            if cx_norm < 0.5:
                action = "STEER_RIGHT"
            else:
                action = "STEER_LEFT"

            # If obstacle is very large (close), just stop
            if blocker.area / self.frame_area > 0.20:
                action = "STOP"

            decision = RoverDecision(
                action=action,
                reason=f"{blocker.label} @ {blocker.confidence:.2f} conf",
                obstacles=centre_obstacles,
                confidence=blocker.confidence,
            )

        self._history.append(decision.action)
        decision.action = self._smoothed_action(decision.action)
        return decision

    def _in_danger_zone(self, d: Detection) -> bool:
        cx_norm = d.cx / self.frame_w
        return DANGER_ZONE_LEFT <= cx_norm <= DANGER_ZONE_RIGHT

    def _smoothed_action(self, current: str) -> str:
        # Only act on a decision if it appears in majority of recent frames
        from collections import Counter
        counts = Counter(self._history)
        majority = counts.most_common(1)[0][0]
        return majority if len(self._history) >= 3 else current

# ─── Visualiser ────────────────────────────────────────────────────────────────

COLOUR_OK      = (80, 200, 80)
COLOUR_DANGER  = (40, 40, 220)
COLOUR_WARN    = (40, 180, 220)
COLOUR_HUD     = (220, 220, 220)

def draw_danger_zone(frame):
    h, w = frame.shape[:2]
    x1 = int(w * DANGER_ZONE_LEFT)
    x2 = int(w * DANGER_ZONE_RIGHT)
    overlay = frame.copy()
    cv2.rectangle(overlay, (x1, 0), (x2, h), (0, 60, 255), -1)
    cv2.addWeighted(overlay, 0.12, frame, 0.88, 0, frame)
    cv2.line(frame, (x1, 0), (x1, h), (0, 80, 255), 1)
    cv2.line(frame, (x2, 0), (x2, h), (0, 80, 255), 1)

def draw_detections(frame, detections: list[Detection], decision: RoverDecision):
    danger_labels = {d.label for d in decision.obstacles}
    for d in detections:
        is_danger = d.label in danger_labels
        colour = COLOUR_DANGER if is_danger else COLOUR_OK
        cv2.rectangle(frame, (d.x1, d.y1), (d.x2, d.y2), colour, 2)
        label = f"{d.label} {d.confidence:.2f}"
        cv2.putText(frame, label, (d.x1, d.y1 - 6),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.5, colour, 1, cv2.LINE_AA)

def draw_hud(frame, decision: RoverDecision, fps: float, latency_ms: float):
    h, w = frame.shape[:2]
    action_colours = {
        "FORWARD":     (80, 200, 80),
        "STOP":        (40, 40, 220),
        "STEER_LEFT":  (40, 200, 220),
        "STEER_RIGHT": (40, 200, 220),
    }
    colour = action_colours.get(decision.action, COLOUR_HUD)

    # Action banner
    cv2.rectangle(frame, (0, 0), (w, 36), (20, 20, 20), -1)
    cv2.putText(frame, f"ACTION: {decision.action}  |  {decision.reason}",
                (10, 24), cv2.FONT_HERSHEY_SIMPLEX, 0.65, colour, 2, cv2.LINE_AA)

    # Stats bar bottom
    cv2.rectangle(frame, (0, h - 28), (w, h), (20, 20, 20), -1)
    stats = f"FPS: {fps:.1f}  |  Latency: {latency_ms:.1f}ms  |  Obstacles: {len(decision.obstacles)}"
    cv2.putText(frame, stats, (10, h - 8),
                cv2.FONT_HERSHEY_SIMPLEX, 0.5, COLOUR_HUD, 1, cv2.LINE_AA)

# ─── Camera check ──────────────────────────────────────────────────────────────

def check_camera(index: int) -> tuple[bool, str]:
    cap = cv2.VideoCapture(index)
    if not cap.isOpened():
        return False, f"Camera index {index} not found"
    ret, frame = cap.read()
    cap.release()
    if not ret or frame is None:
        return False, "Camera opened but could not read a frame"
    h, w = frame.shape[:2]
    return True, f"Camera OK — {w}x{h}"

# ─── Run modes ─────────────────────────────────────────────────────────────────

def run_test_mode():
    """
    Diagnostics: camera check, model load, single-frame detection, FPS estimate.
    No window required — safe to run headless.
    """
    print("\n=== ROVER VISION DIAGNOSTIC ===\n")

    # 1. Camera
    print("[1/4] Checking camera...")
    ok, msg = check_camera(CAMERA_INDEX)
    status = "PASS" if ok else "FAIL"
    print(f"  {status}  {msg}")
    if not ok:
        print("  → Check USB connection or change CAMERA_INDEX in config")
        return

    # 2. Model load
    print("[2/4] Loading YOLO11n model...")
    try:
        t0 = time.perf_counter()
        model = YOLO(MODEL_PATH)
        load_ms = (time.perf_counter() - t0) * 1000
        print(f"  PASS  Model loaded in {load_ms:.0f}ms")
    except Exception as e:
        print(f"  FAIL  {e}")
        return

    # 3. Single inference
    print("[3/4] Running inference on live frame...")
    cap = cv2.VideoCapture(CAMERA_INDEX)
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, CAPTURE_WIDTH)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, CAPTURE_HEIGHT)
    ret, frame = cap.read()
    cap.release()
    if not ret:
        print("  FAIL  Could not capture frame")
        return

    t0 = time.perf_counter()
    results = model(frame, conf=CONF_THRESHOLD, iou=IOU_THRESHOLD, verbose=False)
    inf_ms = (time.perf_counter() - t0) * 1000
    names = model.names
    detections = _parse_detections(results, names)
    print(f"  PASS  Inference: {inf_ms:.1f}ms — {len(detections)} objects detected")
    for d in detections:
        print(f"        {d.label:20s}  conf={d.confidence:.2f}  area={d.area}px²")

    # 4. FPS estimate (20 frames)
    print("[4/4] Estimating FPS (20 frames)...")
    cap = cv2.VideoCapture(CAMERA_INDEX)
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, CAPTURE_WIDTH)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, CAPTURE_HEIGHT)
    times = []
    for _ in range(20):
        ret, frame = cap.read()
        if not ret:
            break
        t0 = time.perf_counter()
        model(frame, conf=CONF_THRESHOLD, iou=IOU_THRESHOLD, verbose=False)
        times.append(time.perf_counter() - t0)
    cap.release()
    if times:
        avg_ms = sum(times) / len(times) * 1000
        fps = 1000 / avg_ms
        print(f"  PASS  Avg latency: {avg_ms:.1f}ms  →  ~{fps:.1f} FPS")
        if fps < 5:
            print("  WARN  FPS is low. Consider reducing CAPTURE_WIDTH or using ONNX export.")
    print("\n=== DIAGNOSTIC COMPLETE ===\n")


def run_live_mode(headless=False):
    """Full live feed with detection + decision + motor stubs."""
    model = YOLO(MODEL_PATH)
    names = model.names
    motor = MotorController(dry_run=True)

    cap = cv2.VideoCapture(CAMERA_INDEX)
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, CAPTURE_WIDTH)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, CAPTURE_HEIGHT)

    if not cap.isOpened():
        print("[ERROR] Cannot open camera")
        return

    ret, sample = cap.read()
    if not ret:
        print("[ERROR] Cannot read from camera")
        cap.release()
        return

    h, w = sample.shape[:2]
    engine = DecisionEngine(w, h)
    fps_counter = deque(maxlen=30)

    print("[LIVE] Running — press Q to quit")
    while True:
        t_frame = time.perf_counter()

        ret, frame = cap.read()
        if not ret:
            print("[WARN] Dropped frame")
            continue

        # Inference
        t_inf = time.perf_counter()
        results = model(frame, conf=CONF_THRESHOLD, iou=IOU_THRESHOLD, verbose=False)
        latency_ms = (time.perf_counter() - t_inf) * 1000

        detections = _parse_detections(results, names)
        decision = engine.decide(detections)

        # Motor commands
        if decision.action == "FORWARD":
            motor.forward()
        elif decision.action == "STOP":
            motor.stop()
        elif decision.action == "STEER_LEFT":
            motor.steer_left()
        elif decision.action == "STEER_RIGHT":
            motor.steer_right()

        # Visualise
        if not headless:
            draw_danger_zone(frame)
            draw_detections(frame, detections, decision)
            fps_counter.append(1.0 / max(time.perf_counter() - t_frame, 1e-9))
            fps = sum(fps_counter) / len(fps_counter)
            draw_hud(frame, decision, fps, latency_ms)

            cv2.imshow("Rover Vision", frame)
            if cv2.waitKey(1) & 0xFF == ord("q"):
                break

    cap.release()
    if not headless:
        cv2.destroyAllWindows()


def run_benchmark_mode(n_frames=100):
    """Pure inference speed benchmark — no display."""
    print(f"\n=== BENCHMARK ({n_frames} frames) ===\n")
    model = YOLO(MODEL_PATH)

    cap = cv2.VideoCapture(CAMERA_INDEX)
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, CAPTURE_WIDTH)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, CAPTURE_HEIGHT)

    times = []
    det_counts = []
    print("Running... ", end="", flush=True)
    for i in range(n_frames):
        ret, frame = cap.read()
        if not ret:
            break
        t0 = time.perf_counter()
        results = model(frame, conf=CONF_THRESHOLD, iou=IOU_THRESHOLD, verbose=False)
        elapsed = time.perf_counter() - t0
        times.append(elapsed)
        det_counts.append(len(results[0].boxes))
        if i % 10 == 0:
            print(".", end="", flush=True)

    cap.release()
    print(" done\n")

    if not times:
        print("No frames captured.")
        return

    avg_ms   = sum(times) / len(times) * 1000
    min_ms   = min(times) * 1000
    max_ms   = max(times) * 1000
    avg_fps  = 1000 / avg_ms
    avg_dets = sum(det_counts) / len(det_counts)

    print(f"  Frames captured : {len(times)}")
    print(f"  Avg latency     : {avg_ms:.1f}ms")
    print(f"  Min / Max       : {min_ms:.1f}ms / {max_ms:.1f}ms")
    print(f"  Avg FPS         : {avg_fps:.1f}")
    print(f"  Avg detections  : {avg_dets:.1f} per frame")
    print()
    if avg_fps >= 15:
        print("  STATUS: GOOD — suitable for real-time rover use")
    elif avg_fps >= 8:
        print("  STATUS: MARGINAL — workable but tune CAPTURE_WIDTH or use ONNX")
    else:
        print("  STATUS: SLOW — export to ONNX/INT8 or reduce resolution")
    print("\n=== BENCHMARK COMPLETE ===\n")

# ─── Helpers ───────────────────────────────────────────────────────────────────

def _parse_detections(results, names) -> list[Detection]:
    detections = []
    for r in results:
        for box in r.boxes:
            cls_id = int(box.cls[0])
            label  = names[cls_id]
            conf   = float(box.conf[0])
            x1, y1, x2, y2 = map(int, box.xyxy[0])
            detections.append(Detection(label, conf, x1, y1, x2, y2))
    return detections

# ─── Entry point ───────────────────────────────────────────────────────────────

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Rover autonomy vision system")
    parser.add_argument("--mode", choices=["test", "live", "benchmark"],
                        default="test", help="Run mode")
    parser.add_argument("--camera", type=int, default=CAMERA_INDEX,
                        help="Camera device index")
    parser.add_argument("--headless", action="store_true",
                        help="Live mode without display window")
    args = parser.parse_args()

    CAMERA_INDEX = args.camera

    if args.mode == "test":
        run_test_mode()
    elif args.mode == "live":
        run_live_mode(headless=args.headless)
    elif args.mode == "benchmark":
        run_benchmark_mode()
